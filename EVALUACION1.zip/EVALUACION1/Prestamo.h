#ifndef PRESTAMO_H_INCLUDED
#define PRESTAMO_H_INCLUDED
#include"Cliente.h"
#include"Pago.h"
#define TAM 10
class Prestamo{
    private:
        int numeroPrestamo;
        Cliente *cliente;
        Fecha *fechaAprobacion;
        float montoAprobado;
        Pago *lstPagos[TAM];
        float saldoPendiente;
        int contadorPagos;
    public:
        Prestamo(){
            this->numeroPrestamo=0;
            this->montoAprobado=0;
            this->saldoPendiente=0;
            this->contadorPagos=0;
        }
        Prestamo(int nP, Cliente *cli, Fecha *fA, float mA){
            this->numeroPrestamo=nP;
            this->cliente=cli;
            this->fechaAprobacion=fA;
            this->montoAprobado=mA;
            this->saldoPendiente=mA;
            this->contadorPagos=0;
        }
        int getNumeroPrestamo(){
            return this->numeroPrestamo;
        }
        void setNumeroPrestamo(int numP){
            this->numeroPrestamo=numP;
        }
        Cliente *getcliente(){
            return this->cliente;
        }
        void setCliente(Cliente *pcli){
            this->cliente=pcli;
        }
        void setFechaAprobacion(Fecha *fA){
            this->fechaAprobacion=fA;
        }
        Fecha *getFechaAprobacion(){
            return this->fechaAprobacion;
        }
        void setMontoAprobado(float mA){
            this->montoAprobado=mA;
        }
         float getMontoAprobado(){
             return this->montoAprobado;
         }
         bool hacerPago(Pago *PAGO){
             bool retorno = false;
             if(this->contadorPagos<TAM){
                this->lstPagos[this->contadorPagos]=PAGO;
                this->contadorPagos++;
                this->saldoPendiente-=PAGO->getMontoPago();
                retorno=true;
             }
             return retorno;
         }
         Pago **getLstPagos(){
             return this->lstPagos;
         }
         float getSaldoPendiente(){
             return this->saldoPendiente;
         }
         int getContadorPagos(){
             return this->contadorPagos;
         }
};





#endif // PRESTAMO_H_INCLUDED
